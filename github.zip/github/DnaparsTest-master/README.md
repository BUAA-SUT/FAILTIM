# DnaparsTest

This file is used for testing the danpars.

# Install

1. git clone git@github.com/Quentinbuaa/DnaparsTest.git
2. cd DnaparsTest/source
3. ./install.sh
4. cd DnaparsTest/exe
5. Modify the workspace in "run.sh" to your <workspace directory>
6. cd DnaparsTest/DnaparsMetamorphicTest
7. Modify the workspace in "Execution.py" variable to your <workspace directory>
8. cd DnaparsTest/DnaparsMetamorphicTest
9. python3 MR.py

