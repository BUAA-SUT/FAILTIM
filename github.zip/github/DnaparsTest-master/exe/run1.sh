workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe
:<<!
for v in {0..1}
do
for i in {0..1} 
do
echo "../inputs/infile_${i}
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}
mv outtree ../outputs/outtree_${v}_${i}
done
done
exec /bin/bash
!
#:<<!
for v in {9..9}
do
for i in {350..499} 
do
echo "../inputs/infile_${i}
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}
mv outtree ../outputs/outtree_${v}_${i}

for j in {0..4} 
do
echo ">>>>>>>>running test ${v}_${i}_${j}"
echo "../inputs/infile_${i}_${j}_f
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}_${j}	
mv outtree ../outputs/outtree_${v}_${i}_${j}
done		
done		
done

exec /bin/bash
#!