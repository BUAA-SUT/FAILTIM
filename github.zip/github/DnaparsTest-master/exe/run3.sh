workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe

#:<<!

echo "../inputs/infile_0
Y"|./dnapars_v0.exe

mv outfile ../outputs2/outfile_0_3
mv outtree ../outputs2/outtree_0_3
		
exec /bin/bash
#!