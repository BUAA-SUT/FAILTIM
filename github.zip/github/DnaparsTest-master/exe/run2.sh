workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe

#:<<!
for i in {0..99} 
do
echo "../inputs/infile_${i}
Y"|./dnapars_v0.exe

mv outfile ../outputs2/outfile_${i}
mv outtree ../outputs2/outtree_${i}

for j in {0..5} 
do
echo ">>>>>>>>running test ${i}_${j}"
echo "../inputs/infile_${i}_${j}_f
Y"|./dnapars_v0.exe

mv outfile ../outputs2/outfile_${i}_${j}	
mv outtree ../outputs2/outtree_${i}_${j}
done		
done		
exec /bin/bash
#!