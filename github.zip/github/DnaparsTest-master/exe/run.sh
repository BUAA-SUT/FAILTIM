workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe
echo "../inputs/$2
Y"|./dnapars_$1

mv outfile ../outputs/$3	
mv outtree ../outputs/$4
exec /bin/bash