workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe
:<<!
for v in {0..1}
do
for i in {0..1} 
do
echo "../inputs/infile_${i}
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}
mv outtree ../outputs/outtree_${v}_${i}
done
done
exec /bin/bash
!
#:<<!  
for v in {3..3}
do
for i in {50..99} 
do
for x in {5..10}
do
for y in {0..10}
do
echo "../inputs/infile_${i}_${x}_f_${y}_f
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}_${x}_${y}	
mv outtree ../outputs/outtree_${v}_${i}_${x}_${y}
done
done		
done
		

done

exec /bin/bash
#!