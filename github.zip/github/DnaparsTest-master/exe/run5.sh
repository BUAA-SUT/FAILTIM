workspace=D:/程序/博士/MT/metamorphic-testing-master/tests/DnaparsTest-master
cd $workspace/exe
:<<!
for v in {0..1}
do
for i in {0..1} 
do
echo "../inputs/infile_${i}
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}
mv outtree ../outputs/outtree_${v}_${i}
done
done
exec /bin/bash
!
#:<<!  
for v in {4..10}
do
for i in {0..99} 
do
for j in {5..10}
do
echo "../inputs/infile_${i}_${j}_f
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}_${j}	
mv outtree ../outputs/outtree_${v}_${i}_${j}

done		
done

for i in {0..99} 
do
for m in {0..4}
do
for n in {5..10}
do
echo "../inputs/infile_${i}_${m}_f_${n}_f
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}_${m}_${n}	
mv outtree ../outputs/outtree_${v}_${i}_${m}_${n}
done
done		
done

for i in {0..99} 
do
for x in {5..10}
do
for y in {0..10}
do
echo "../inputs/infile_${i}_${x}_f_${y}_f
Y"|./dnapars_v${v}.exe

mv outfile ../outputs/outfile_${v}_${i}_${x}_${y}	
mv outtree ../outputs/outtree_${v}_${i}_${x}_${y}
done
done		
done
		

done

exec /bin/bash
#!