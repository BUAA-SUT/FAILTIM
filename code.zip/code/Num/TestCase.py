class TestCase:
    def __init__(self):
        pass

    def setInputOutput(self, input_name, output_name):
        self.input = input_name
        self.output = output_name




